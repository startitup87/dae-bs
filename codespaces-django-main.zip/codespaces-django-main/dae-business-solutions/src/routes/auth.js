import express from 'express';

const router = express.Router();

router.post('/login', (req, res) => {
    res.send('User login');
});

router.post('/register', (req, res) => {
    res.send('User registration');
});

router.post('/logout', (req, res) => {
    res.send('User logout');
});

router.get('/me', (req, res) => {
    res.send('Authenticated user details');
});

export default router;