import express from 'express';

const router = express.Router();

router.get('/', (req, res) => {
    res.send('List all orders');
});

router.get('/:id', (req, res) => {
    res.send(`Get details of order with ID ${req.params.id}`);
});

router.post('/', (req, res) => {
    res.send('Create a new order');
});

router.put('/:id', (req, res) => {
    res.send(`Update order with ID ${req.params.id}`);
});

router.delete('/:id', (req, res) => {
    res.send(`Cancel order with ID ${req.params.id}`);
});

export default router;