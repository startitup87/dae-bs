const express = require('express');
const router = express.Router();

// Example controller function
router.get('/', (req, res) => {
    res.send('Welcome to the DAE Business Solutions API');
});

// Export the router
module.exports = router;