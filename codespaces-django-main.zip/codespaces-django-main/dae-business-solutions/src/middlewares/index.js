import { json, urlencoded } from 'express';

const requestLogger = (req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
};

const errorHandler = (err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
};

const middleware = {
    requestLogger,
    errorHandler,
    jsonParser: json(),
    urlencodedParser: urlencoded({ extended: true }),
};

export default middleware;